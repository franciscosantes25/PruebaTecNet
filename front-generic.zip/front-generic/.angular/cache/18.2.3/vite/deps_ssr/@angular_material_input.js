import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-PM4DJPBY.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-R4PVDXIF.js";
import "./chunk-LUSYMTEW.js";
import "./chunk-FJMS3ORN.js";
import "./chunk-MXT4JVV4.js";
import "./chunk-M26M6KQO.js";
import "./chunk-DH64UGMO.js";
import "./chunk-VDZEJD3D.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
