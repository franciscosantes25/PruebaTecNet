import { Component } from '@angular/core';

@Component({
  selector: 'app-states',
  standalone: true,
  imports: [],
  templateUrl: './states.component.html',
  styleUrl: './states.component.css'
})
export class StatesComponent {

}
