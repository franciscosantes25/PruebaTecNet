import { Component } from '@angular/core';

@Component({
  selector: 'app-position',
  standalone: true,
  imports: [],
  templateUrl: './position.component.html',
  styleUrl: './position.component.css'
})
export class PositionComponent {

}
