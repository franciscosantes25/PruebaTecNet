export const enviroment = {
    appUrl : 'http://localhost:40223/api/'
}